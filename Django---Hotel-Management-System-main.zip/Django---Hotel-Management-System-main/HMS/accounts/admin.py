from django.contrib import admin
from .models import *

# Register your models here.
admin.site.register(Guest)
admin.site.register(Employee)
admin.site.register(Task)
